###########################################################
#         Warsztaty Machine Learning w programie R        #
#                    Piotr Ćwiakowski                     #
#                       LabMasters                        #
#                Market Basket Analysis                   #
###########################################################


# Ścieżka dostępu
setwd('...')


# instalacja pakietów
install.packages('arules')
install.packages('arulesViz')

# Biblioteki
library(arules)
library(arulesViz)
library(tidyverse)
library(datasets)

# Baza danych
data(Groceries)

# Obejrzyjmy strukturę danych
# Ważne przed rozpoczęciem analizy!!
glimpse(Groceries)
head(Groceries)


# To nie jest zwuykły data.frame...
Groceries@data
Groceries@itemInfo
Groceries@itemsetInfo


# Zapisanie do data.frame
a <- as(Groceries, "data.frame")

# Prawie 10 tys. transakcji Ale przecież nie o to chodziło...

# Jak stworzyć taki obiekt?
# Odpowiedź znajduje się w dokumentacji
# https://www.rdocumentation.org/packages/arules/versions/1.5-3/topics/transactions-class

# Bazę danych groceries zostawmy na zadanie własne. Przyjrzyjmy się przykładowi:
a <- read.csv('0 Dane/mba - przyklad.csv')
a <- split(a$Products, a$ID)
a

# Stworzenie obiektu klasy transactions
b = as(a,"transactions")
summary(b)
inspect(b)

# Najczęściej powtarzające się produkty
itemFrequency(b, type = "relative")
itemFrequencyPlot(b,topN = 15)

# aggregated data
rules = apriori(b, parameter=list(support=0.005, confidence=0.8))
rules = apriori(b, parameter=list(support=0.005, confidence=0.8, minlen = 3))
rules = apriori(b, parameter=list(support=0.005, confidence=0.8, maxlen = 4))

# Konwersja na data.frame i eksport wyników
rules3 = as(rules, "data.frame")
write(rules, "C:\\Users\\Deepanshu\\Downloads\\rules.csv", sep=",")

# Wyświetlenie reguł tylko dla zakupu H:
inspect( subset( rules, subset = rhs %pin% "Product H" ))

# 10 pierwszych reguł
options(digits=2)
inspect(rules[1:10])

# Podsumowanie wyników
summary(rules)

# Sortowanie po konkretnej charakterystyce
rules <- sort(rules, by="lift", decreasing=TRUE)

