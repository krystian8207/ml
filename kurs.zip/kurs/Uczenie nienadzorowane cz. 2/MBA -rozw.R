setwd('/Users/piotrcwiakowski/Dropbox/4 Machine Learning R/2_3 Zajecia')



# Wykres najczęściej wybieranych produktów
itemFrequencyPlot(Groceries,topN=20,type="absolute")


# Policzenie reguł dla poziomu wsparcia 0.001 i pewności 0.8
rules <- apriori(Groceries, parameter = list(supp = 0.001, conf = 0.8))

# Zaprezentowanie najpopularniejszych reguł
options(digits=2)
inspect(rules[1:5])

# Podsumwanie transakcji
summary(rules)

# Obróbka wyników
rules<-sort(rules, by="confidence", decreasing=TRUE)
inspect(rules[1:5])

# Wyświetlenie wykresu sieci:
plot(rules,method="graph",interactive=TRUE,shading=NA)

install.packages('tcltk2')


# https://cran.r-project.org/src/contrib/Archive/tcltk2/ 

# Więcej informacji:
# http://blog.revolutionanalytics.com/2015/04/association-rules-and-market-basket-analysis-with-r.html
# http://www.listendata.com/2015/12/market-basket-analysis-with-r.html
# https://github.com/snowplow/snowplow/wiki/Setting-up-R-to-perform-more-sophisticated-analysis-on-your-Snowplow-data
# https://discourse.snowplowanalytics.com/t/market-basket-analysis-identifying-products-and-content-that-go-well-together/1132