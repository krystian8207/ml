###########################################################
#         Warsztaty Machine Learning w programie R        #
#                    Piotr Ćwiakowski                     #
#                       LabMasters                        #
#               Analiza Głównych Składowych               #
###########################################################


setwd('...')

# install.packages('factoextra')
# install.packages('corrplot')
# install.packages('FactoMineR')
# install.packages('rgl')
# install.packages('car')
# install.packages('psych')
# install.packages('pls')
library(rgl)
library(car)
library(factoextra)
library(corrplot)
library(FactoMineR)
library(car)
library(psych)
library(pls)

###################################################################
## Wczytanie danych
f <- read.csv('0 Dane/footballers2.csv', sep=';', dec='.', stringsAsFactors = F)

rownames(f) <- f$name #nazwy pilkarzy zamiast numerów nazwami wierszy
f$name<-NULL #usuni?cie zmiennej ze zbioru

summary(f) #przyjrzyjmy się zmiennym mierzonym na tej samej skali.

# Na tych zmiennych pca (liczba bramek)
f.pca <- f[,5:10]

# Analiza korelacji
cor.mat <- round(cor(f.pca),2)
corrplot::corrplot(cor.mat, type="upper", order="hclust", 
                   tl.col="black", tl.srt=45)

# Diagnostyka:
 
# Test Bartletta na intrakorelacje
psych::cortest.bartlett(f.pca)
 
# współczynnik KMO (Kaiser-Meyer-Olkin), powinien być powyżej 0.7
psych::KMO(cor.mat)
 
#################################################################
# Wizualizacja i analiza wyników
# Źródło:
# http://www.sthda.com/english/wiki/cluster-analysis-in-r-unsupervised-machine-learning

obiekt.pca <- PCA(f.pca, graph = FALSE)

# Wykres łokciowy
fviz_screeplot(obiekt.pca, ncp=10, ylim = c(0, 50))
summary(obiekt.pca)

# Wyświetlmy łącznie z wartościami własnymi
fviz_eig(obiekt.pca, addlabels = TRUE, ylim = c(0, 50))

# Wykres zmiennych w pca
fviz_pca_var(obiekt.pca, col.var="steelblue") +
  theme_minimal()

# Włącznie z kontrybucją do wymiarów (korelacja)
fviz_pca_var(obiekt.pca, col.var="contrib") +
scale_color_gradient2(low="white", mid="blue", 
                      high="red", midpoint=15)+theme_bw()

# Jakość reprezentacji w wymiarach
diagnostyka <- get_pca_var(obiekt.pca)
diagnostyka

# Dysponujemy trzema charakterystykami:
# cor - korelacją zmiennych z komponentami
# cos2 - jakością reprezentacji zmiennych na komponentach
# contrib - wielkość kontrybucji zmiennej do komponentu

# Chcemy się dowiedzieć:
# a) które zmienne są reprezentowane przez który wymiar?
# b) które zmienne są skorelowane z nimi (podobnie zmieniają sie ich wartości)?
# c) które zmienne mają wysoki wkład w całkowitą informację o wymiarze?

# Oczywiście informacje te są od siebie współzależne, ale ponieważ w skład ładunku wchodzi wiele zmiennych, 
# to nie koniecznie muszą być równoznaczne.


# a) Jakość reprezentacji zmiennych:
corrplot(diagnostyka$cos2, is.corr=FALSE)
fviz_cos2(obiekt.pca, choice = "var", axes = 1:2)
fviz_pca_var(obiekt.pca, col.var = "cos2",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
             repel = TRUE # Avoid text overlapping
)

# b) Kontrybucja:
corrplot(diagnostyka$contrib, is.corr=FALSE) 
# Kontrybucja do wymiaru PC1
fviz_contrib(obiekt.pca, choice = "var", axes = 1, top = 10)
# Kontrybucja do wymiaru PC2
fviz_contrib(obiekt.pca, choice = "var", axes = 2, top = 10)

fviz_pca_var(obiekt.pca, col.var = "contrib",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07")
)

# Charakterystyka wymiaru
res.desc <- dimdesc(obiekt.pca, axes = c(1,2), proba = 0.05)
res.desc$Dim.1
res.desc$Dim.2

# Wykres piłkarzy
fviz_pca_ind(obiekt.pca, geom="text")

# Jakość reprezentacji w wymiarach 
fviz_pca_ind(obiekt.pca, col.ind="cos2") +
  scale_color_gradient2(low="white", mid="blue", 
                        high="red", midpoint=0.50)

# Pokolorujmy punkty wg różnych kategorii
f$val_kat <- cut(f$market_value,breaks=5)

fviz_pca_ind(obiekt.pca, label = 'none', habillage=f$val_kat,
             addEllipses=T, ellipse.level=0.95)

# Na koniec biplot
fviz_pca_biplot(obiekt.pca,  geom = "text")

####################################################################################
# Prognozowanie wartości dla oszacowanego modelu PCA
# nowy_zbior - obiekt musi mieć takie same zmienne jak zbiór treningowy

# Wybierzmy kilka obserwacji ze zbioru treningowego i użyjmy go jako testowy.
nowy_zbior <- f[1:10,5:10]

fit <- predict(obiekt.pca, nowy_zbior)

fit$coord[,1]

# A w bazie pierwotnej..
obiekt.pca$ind$coord[1:10,1]

# Czyli skalowanie jest automatyczne.

################################################################################
# CASE STUDY - ROTACJA I INTERPRETACJA CZYNNIKÓW

# Do wyjaśnienia tej części skorzystajmy z innej bazy - diagnoza społeczna.
# Opis zbioru znajduje się w osobnym pliku
h <- read.csv("0 Dane/zadowolenie.csv", header = T, sep = ";")
names(h)
#Krok 1. Wybór liczby kompentów
h.pca <- princomp(h[,16:31], cor = TRUE)
#Krok 2. Wariancja
summary(h.pca)
#Krok 3. Wykres łokcia
plot(h.pca, type = "lines")

h.pca$scores

# użycie komendy z biblioteki psych - rotacja wektora w celu maksymalizacji wartości ładunków na 
# jednym z komponentów
h.pca.rot <- psych::principal(h[,16:31], nfactors = 5, rotate = "varimax")
h.pca.rot

#interpretacja - zróbmy to w excelu.

#zapisanie czynników do zmiennych
h.index <- principal(h[,16:31], nfactors = 5, rotate = "varimax", scores = TRUE)$scores
h.index <- as.data.frame(h.index)
head(h.index)

#przejdźmy do interpretacji -> plik word
names(h.index)[1] ="PC1_zycie_zawodowe "
names(h.index)[2] ="PC2_zycie rodzinne"
names(h.index)[3] ="PC3_warunki_srodowiskowe"
names(h.index)[4] ="PC4_bezpieczenstwo"
names(h.index)[5] ="PC5_zdrowie i znajomi"

## Przykład 1. Normalizacja i wizualizacja indeksów PCA  
head(h.index)
h.index.norm = round((h.index[1] - min(h.index[1]))/(max(h.index[1]) - min(h.index[1]))*100)
head(h.index.norm)
mode(h.index.norm) #obiekt jest listą, zamieńmy na macierz
h.index.norm <- as.matrix(h.index.norm)

par(bg="white")
hist(as.double(h.index.norm),
     col = topo.colors(9),
     main = "Rozkład satysfakcji z życia zawodowego",
     xlab = "indeks od 0 do 100 punktów")

#Pozostałe zmienne również przeskalujmy:
h.index.norm2 = (h.index[2] - min(h.index[2]))/(max(h.index[2]) - min(h.index[2]))*100
h.index.norm3 = (h.index[3] - min(h.index[3]))/(max(h.index[3]) - min(h.index[3]))*100
h.index.norm4 = (h.index[4] - min(h.index[4]))/(max(h.index[4]) - min(h.index[4]))*100
h.index.norm5 = (h.index[5] - min(h.index[5]))/(max(h.index[5]) - min(h.index[5]))*100

## Przykład 2. Średnie arytmetyczna czynników zgodnie z wynikami analizy PCA: 
h.mean.index.1 <- (h[,20] + h[,26] + h[,27] + h[,28])/4
h.mean.index.2 <- (h[,16] + h[,25] + h[,29] + h[,30])/4
h.mean.index.3 <- (h[,17] + h[,21] + h[,24])/3
h.mean.index.4 <- (h[,22] + h[,23] + h[,31])/3
h.mean.index.5 <- (h[,18] + h[,19])/2
hist(h.mean.index.1, col = "blue3", main = "Rozkład satysfakcji z życia zawodowego")

## Połączenie w jeden zbiór
h.mean.index = as.data.frame(cbind(h.mean.index.1, h.mean.index.2, h.mean.index.3, h.mean.index.4, h.mean.index.5))
head(h.mean.index)

# Nazwanie kolumn
names(h.mean.index)[1] ="Z_zycie_zawodowe"
names(h.mean.index)[2] ="Z_zycie rodzinne"
names(h.mean.index)[3] ="Z_warunki_mieszkaniowe"
names(h.mean.index)[4] ="Z_bezpieczenstwo"
names(h.mean.index)[5] ="Z_zdrowie i znajomi"

#scalanie w jeden zbiór
h.wyniki <- cbind(h, h.index, h.mean.index, h.index.norm)
names(h.wyniki)
head(h.wyniki)
write.csv(h.wyniki, "zadowolenie_analiza.csv")
names(h)

## regresja z wykorzystaniem PCA
model <- lm(ocena.zycie ~ doch.netto + h_najblizsi + h_fin_rodzina + h_znajomi + h_zdrowie + h_sukcesy + h_kraj + 
            h_mieszkanie + h_miejscowosc + h_perspektywy + h_seks +  h_wyksz + h_wolny_czas + h_praca +  
            h_dzieci + h_malzenstwo, data = h)
summary(model)
car::vif(model)

model2 <- lm(h$ocena.zycie ~ h$doch.netto + h.wyniki[,32] + h.wyniki[,33] + h.wyniki[,34] + h.wyniki[,35] + h.wyniki[,36])
summary(model2) #takie samo R2, większa czytelność wyników i lepszy model.
car::vif(model2) 

### Przeprowadźmy to samo za pomocą procedury pls
pcr_model <- pcr(ocena.zycie ~ h_najblizsi + h_fin_rodzina + h_znajomi + h_zdrowie + h_sukcesy+ h_kraj + 
                   h_mieszkanie + h_miejscowosc + h_perspektywy + h_seks +  h_wyksz +  h_wolny_czas + h_praca+  
                   h_dzieci + h_malzenstwo, data = h, scale = TRUE)
summary(pcr_model)

### Na zajęciach poświęconych metodom regresyjnym poświęcimy tym metodom więcej czasu.

# Więcej informacji:
browseURL('https://www.r-bloggers.com/naive-principal-component-analysis-using-r/')
browseURL('http://ucanalytics.com/blogs/principal-component-analysis-step-step-guide-r-regression-case-study-example-part-4/')
browseURL('https://www.r-bloggers.com/computing-and-visualizing-pca-in-r/')
browseURL('http://web.missouri.edu/~huangf/data/mvnotes/Documents/pca_in_r_2.html')
browseURL('https://www.cbn.gov.ng/out/2013/sd/cbn%20jas%20volume%203%20number%202_article%203.pdf')
browseURL('https://www.r-bloggers.com/performing-principal-components-regression-pcr-in-r/')

########################################################################################
# MDS - skalowanie wielowymiarowe
# Multidimensional scaling to technika służąca do analizowania podobieństw i różnic
# w bazie danych. MDS dąży do zmapowania n-wymiarowej przestrzeni do mniejszej, 
# przy jak najepszym odwzorowaniu odległości pomiędzy nimi. 
# 
# W PCA zastanawiamy się nad konceptualizacją wielu zmiennych w mniejszej przestrzeni,
# W MDS, mając macierz odległości/podobieństwa, staramy się przedstawić punkty w 
# zadanych wymiarach - mapujemy je.

# Skalowanie MDS metryczne
d <- dist(mtcars) # policzenie macierzy euklidesowej
fit <- cmdscale(d, eig = TRUE, k = 2) # skalowanie do dwóch wymiarów
fit # zaprezentowanie rezultatów

# Wizualizacja wyników
x <- fit$points[,1]
y <- fit$points[,2]
plot(x, y, xlab = "Coordinate 1", ylab = "Coordinate 2", 
     main="Metric	MDS",	type="n")
text(x, y, labels = row.names(mtcars), cex=.7)

# Ćwiczenie. 
# Wczytaj bazę swiss.csv i wykonaj skalowanie wielowymiarowe dla kantonów. Spróbuj wykonać wizualizację za pomocą
# pakietu ggplot2.










# Więcej informacji:
browseURL('http://gastonsanchez.com/visually-enforced/how-to/2013/01/23/MDS-in-R/')
browseURL('https://ncss-wpengine.netdna-ssl.com/wp-content/themes/ncss/pdf/Procedures/NCSS/Multidimensional_Scaling.pdf')
browseURL('http://www.statmethods.net/advstats/mds.html')

##############################
#   Materiały dodatkowe      #
##############################

########################################################################################
# Analiza czynnikowa

# Analiza czynnikowa służy przede wszystkim w psychologii do wykrywania czynników ukrytych, szukania
# na podstawie obserwowalnych charakterystyk pewnych ukrytych konstruktów.

wartosci<-na.omit(read.csv("0 Dane/Analiza czynnikowa/wartosci_w_zyciu.csv", header=T, sep=";",na.strings = "."))
names(wartosci)
psych::KMO(wartosci[,14:27]) # niska wartość KMO, wykonujemy analizę czynnikową
factanal(wartosci[,14:27], factors=5)  #domyślnie opcja varimax
#Uniqueness - udział odrębnej wariancji w analizie - jeśli za duża - nie dobrze

# Możliwe różne rotacje
psych::fa(wartosci[,14:27], nfactors=6,rotate="varimax")
psych::fa(wartosci[,14:27], nfactors=6,rotate="oblimin")

# Analiza czynnikowa, zwana również potwierdzającą analizą czynnikową (Confirmatory Factor Analysis) 
# można uogólnić do klasy metod zwanej Structural Equation Modelling, która pozwala na modelowania
# skomplikwanych układów zależności pomiędzy czynnikami.


browseURL('https://web.stanford.edu/class/psych253/tutorials/FactorAnalysis.html')


