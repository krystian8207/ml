x <- (1:10)^2
names(x) <- letters[1:10]
d1 <- x %>% dist %>% hclust("com") %>% as.dendrogram
d1 %>% fviz_dend
d2 <- x %>% dist %>% hclust("ward.D2") %>% as.dendrogram
d2 %>% fviz_dend
dend12 <- dendlist(d1, d2)

tanglegram(d1, d2,
           highlight_distinct_edges = FALSE, 
           common_subtrees_color_lines = T,
           common_subtrees_color_branches = T, 
           main = paste("entanglement =", round(entanglement(dend12), 2)))


cor.dendlist(dend12, method = "cophenetic")
cor.dendlist(dend12, method = "baker")
