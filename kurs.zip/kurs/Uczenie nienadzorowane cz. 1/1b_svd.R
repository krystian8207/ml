###########################################################
#         Warsztaty Machine Learning w programie R        #
#                    Piotr Ćwiakowski                     #
#                       LabMasters                        #
#             Redukcja wymiarów za pomocą SVD             #
###########################################################


# Ustalenie ścieżki dostępu
setwd('...')

# Wczytanie danych
f <- read.csv('0 Dane/footballers2.csv', sep = ';')
rownames(f) <- f$name #nazwy pilkarzy zamiast numerów nazwami wierszy
f$name<-NULL #usuni?cie zmiennej ze zbioru

summary(f) #przyjrzyjmy się zmiennym mierzonym na tej samej skali.

# Redukujemy wymiary dla liczby bramek:
f.g <- f[,5:10]

# Wycentrowanie danych
f.g.cent <- drop(scale(f.g))

# Policzenie PCA i SVD na danych 
# wystandaryzowanych i surowych 
pca.raw <- prcomp(f.g)
svd.raw <- svd(f.g)
pca.cent <- prcomp(f.g.cent)
svd.cent <- svd(f.g.cent)

# Przyrzyjmy się obiektowi SVD:
names(svd.raw)

dim(svd.raw$u)
head(svd.raw$u)
svd.raw$d

par(mfrow=c(1,4))
plot(svd.raw$u[,1],1:258,pch=19)
plot(svd.raw$u[,2],1:258,pch=18)
plot(svd.raw$u[,3],1:258,pch=17)
plot(svd.raw$u[,4],1:258,pch=16)
par(mfrow=c(1,1))

# Rozwiązanie SVD dla pierwszych dwóch wektorów:
plot(svd.cent$u[,1], svd.cent$u[,2], pch = 19,
     xlab = "SV1", ylab = "SV2")

plot(pca.cent$x[,1], pca.cent$x[,2], pch=19, 
     xlab="PC1", ylab="PC2")

# Porównanie danych rozwiązań na zmiennych niewycentrowanych:
plot(svd.raw$u[,1], svd.raw$u[,2], pch = 19,
     xlab = "SV1", ylab = "SV2")

plot(pca.raw$x[,1], pca.raw$x[,2], pch=19, 
     xlab="PC1", ylab="PC2")

# Wykres osypiska dla svd
svd.cent$d^2/sum(svd.cent$d^2)
plot(svd.cent$d^2/sum(svd.cent$d^2), pch = 19, type = 'b',
     xlab="wektory własne SVD", ylab = "Wyjaśniona wariancja")

# Wykres osypiska dla PCA
pca.cent$sdev^2/sum(pca.cent$sdev^2)
plot(pca.cent$sdev^2/sum(pca.cent$sdev^2), pch = 19, type = 'b',
     xlab="wektory własne PCA", ylab = "Wartości własne")

# Otrzymanie wartości wyjściowych
original <- round(svd.raw$u %*% diag(svd.raw$d) %*% t(svd.raw$v))
head(original)

head(f.g)



# Źródło:
# http://genomicsclass.github.io/book/pages/pca_svd.html
# https://rpubs.com/aaronsc32/singular-value-decomposition-r
# https://www.r-bloggers.com/singular-value-decomposition-svd-tutorial-using-examples-in-r/
