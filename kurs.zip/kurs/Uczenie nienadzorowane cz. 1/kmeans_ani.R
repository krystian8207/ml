library(animation)

ani.options(interval = 1)
par(mar = c(3, 3, 1, 1.5), mgp = c(1.5, 0.5, 0))
kmeans.ani()

x = rbind(
  matrix(rnorm(100, sd = 0.3), ncol = 2), 
  matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
colnames(x) = c("x", "y")
kmeans.ani(x, centers = 2)

kmeans.ani(x, centers = 3)