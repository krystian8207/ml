library(factoextra)
x <- 20 * (runif(100) - 0.5)
y <- runif(100)
df <- data.frame(x, y)
df2 <- spdep::Rotation(df, pi/3)
df2 <- as.data.frame(df2)
names(df2) <- c("x", "y")
df3 <- spdep::Rotation(df, 2 * pi/3)
df3 <- as.data.frame(df3)
names(df3) <- c("x", "y")

df <- rbind(df, df2, df3)

plot(df)