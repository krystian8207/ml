###########################################################
#         Warsztaty Machine Learning w programie R        #
#                    Piotr Ćwiakowski                     #
#                       LabMasters                        #
#               Przegląd technik segmentacji              #
###########################################################
# Źródło:
# http://www.sthda.com/english/wiki/cluster-analysis-in-r-unsupervised-machine-learning

# Ścieżka dostępu
setwd('...')

# Instalacja paketów
# install.packages('factoextra')
# install.packages('corrplot')
# install.packages('FactoMineR')
# install.packages('cluster')
# install.packages('fpc')
# install.packages('clValid')
# install.packages('dendextend')
# install.packages('NbClust')
# install.packages('car')
# install.packages('gplots')
# install.packages('mclust')
# install.packages("fpc")
# install.packages("dbscan")

# Wczytanie bibliotek
library(factoextra)
library(corrplot)
library(FactoMineR)
library(cluster)
library(fpc)
library(clValid)
library(dendextend)
library(NbClust)
library(car)
library(gplots)
library(mclust)
library(fpc)
library(dbscan)

# Wczytanie danych
f <- read.csv('0 Dane/footballers2.csv', sep=';', dec='.')
rownames(f)<-f$name #nazwy piłkarzy zamiast numerów nazwami wierszy
f$name<-NULL #usunięcie zmiennej ze zbioru
# Wybór zmiennych do algorytmu
d <- f[,-c(1,23)]

#############################################################################################
# Klastrowanie hierarchiczne (aglomeracyjne, AGNES)
dend <- hcut(d, # dane
             k = 4, # liczba klastrów
             stand = TRUE, # czy standaryzujemy?
             hc_method = "ward.D2", # jaką metodą liczymy najbliższego sąsiada
             hc_metric = "pearson" # jaką metrykę przyjmujemy do liczenia odległości
             )

# Wizualizacja wyników jako drzewo
fviz_dend(dend, 
          rect = TRUE,# czy zaznaczać klastry prostokątami?
          cex = 0.5, # wielkość czcionki
          type = "rectangle", #"circular", "phylogenic"),
          k_colors = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07") # kolory dla klastrów
          )
# Wizualizacja przy pomocy PCA
klastry <- cutree(dend, k = 4)
fviz_cluster(list(data = scale(d), cluster = klastry),
             palette = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07"), 
             ellipse.type = "convex", # Concentration ellipse
             repel = F, # Avoid label overplotting (slow)
             labelsize = 10, 
             show.clust.cent = FALSE, ggtheme = theme_minimal())

# Zróbmy drugie drzewo
dend2 <- hcut(d, # dane
             k = 4, # liczba klastrów
             stand = TRUE, # czy standaryzujemy?
             hc_method = "ward.D2", # jaką metodą liczymy najbliższego sąsiada
             hc_metric = "euclidean" # jaką metrykę przyjmujemy do liczenia odległości
)
klastry <- cutree(dend2, k = 3)
fviz_cluster(list(data = scale(d), cluster = klastry),
             palette = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07"), 
             ellipse.type = "convex", # Concentration ellipse
             repel = F, # Avoid label overplotting (slow)
             labelsize = 10, 
             show.clust.cent = FALSE, ggtheme = theme_minimal())

# Wizualizacja wyników jako drzewo
fviz_dend(dend2, 
          rect = TRUE,# czy zaznaczać klastry prostokątami?
          cex = 0.5, # wielkość czcionki
          type = "rectangle", #"circular", "phylogenic"),
          k_colors = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07") # kolory dla klastrów
)

# Macierz przejścia
table(dend$cluster, dend2$cluster) %>% 
  addmargins()

############################################################################################
# Wizualizacja 3D w klastrów
obiekt.pca <- PCA(scale(d), graph = FALSE)

scatter3d(x = obiekt.pca$ind$coord[,1], 
          y = obiekt.pca$ind$coord[,2], 
          z = obiekt.pca$ind$coord[,3], 
          groups = factor(dend$cluster),
          grid = FALSE, 
          ellipsoid = TRUE,
          surface = F,
          surface.col = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07")
)

############################################################################
# Porównanie dwóch drzew:
library(dendextend)
dend_list <- dendlist(as.dendrogram(dend), as.dendrogram(dend2))
tanglegram(dend, dend2,
           highlight_distinct_edges = FALSE, 
           common_subtrees_color_lines = T,
           common_subtrees_color_branches = T, 
           main = paste("entanglement =", round(entanglement(dend_list), 2))
)
# Za dużo obserwacji....


# Współczynniki korelacji rozwiązań:
cor.dendlist(dend_list, method = "cophenetic")
cor.dendlist(dend_list, method = "baker")


###########################################################################
# Ćwiczenie
# wczytaj bazę nba.csv i wykonaj dwa dendrogramy różnymi metodami. Następnie porównaj między sobą wyniki.









# Więcej informacji tutaj:
# http://www.sthda.com/english/articles/28-hierarchical-clustering-essentials/91-comparing-dendrograms-essentials/

############################################################################
# Dodatkowe opcje wizualizacji
fviz_dend(dend, 
          rect = TRUE,# czy zaznaczać klastry prostokątami?
          cex = 0.5, # wielkość czcionki
          horiz = T,
          rect_fill = T,
          type = "rectangle", #"circular", "phylogenic"),
          k_colors = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07") # kolory dla klastrów
)
# Więcej informacji tutaj:
# http://www.sthda.com/english/articles/28-hierarchical-clustering-essentials/92-visualizing-dendrograms-ultimate-guide/


###########################################################################
# Heatmapy
# Umożliwiają klasteryzacje zarówno zmiennych jak i obserwacji

# Bez skalowania
heatmap(as.matrix(d), scale = "none")
heatmap(scale(as.matrix(d)), scale = "none")


heatmap(as.matrix(d), scale = "row")
heatmap(as.matrix(d), scale = "column")

# Pakiet gplots
heatmap.2(scale(as.matrix(d)), scale = "none", col = bluered(100), 
          trace = "none", density.info = "none")

# Więcej informacji tutaj:
# http://www.sthda.com/english/articles/28-hierarchical-clustering-essentials/93-heatmap-static-and-interactive-absolute-guide/

###########################################################################
# Ćwiczenie
# Wykonaj heatmapę na bazie nba.csv 









############################################################################
# Ewaluacja wyników

# Kryteria oceny klastrów dzielą się na:
# kryteria wewnętrzne - statystyki mówiące o homegeniczności wewnętrznej i zróżnicowaniu pomiędzy klastrami
# kryteria zewnętrzne - hipotezy a priori o liczbe i typier klastrów 
# kryteria relatywne - porównywanie rozwiązań dla różnej liczby klastrów

# W walidacji wewnętrznej zależy nam na trzech kryteriach:
# spójność (compactness) - jak bardzo obiekty są do siebie podobne w ramach tego samego klastra?
# separacja - jak bardzo obserwacje pomiędzy klastrami różnią się od siebie?
# łączność (connectivity) - czy obserwacje które są koło siebie należą do tego samego klastra?


# Czy dane nadają się do klastrowania?
get_clust_tendency(scale(d), n = 50,
                   gradient = list(low = "orange",  high = "white"))

# Jeśli współczynnik Hopkinsa poniżej 0.5 - dane można klastrować. Jeśli powyżej - grupa jednorodna

# Jakość klastrów (homogeniczność grup)
fviz_silhouette(dend) # Słabe różnice pomiędzy klastrami

# indeks mierzący jak i-ty obiekt jest podobny do pozostałych obiektów ze swojego klastra, vs. obiektów z innych klastrów
# statystyka ma wartości od -1 do 1, jest liczona dla każdej obserwacji i następnie podawana jest średnia dla całej próby 

# Jak wybrać odpowiednią metodę?
intern <- clValid(scale(d), nClust = 2:6, 
              clMethods = c("hierarchical","kmeans","pam"),
              validation = "internal")
# Summary
summary(intern)

# Statystyka Connectivity - im mniej tym lepiej 
# Statystyka Dunna - im więcej tym lepiej
# Silhoute - im bliżej jeden tym lepiej

# Możemy także sprawdzić odporność naszych metod na różne algorytmy i różną 
# liczbę klastrów
stab <- clValid(scale(d), nClust = 2:6, clMethods = c("hierarchical","kmeans","pam"),
                validation = "stability")

# APN (Average proportion of non-overlap) - proporcja obserwacji zmieniających swój klaster, 
# pomiędzy segmentacją na pełnym zbiorze i segmentacją bez jednej kolumny.
# AD (Average distance) - średni dystans pomiędzy obserwacjami z tego samego 
# klastra w sytuacji pełnego zbioru i zbioru z k-1 kolumnami 
# ADM (average distance between means) - średni dystans pomiędzy centroidami
# FOM (figure of merit) - średnia wariancja intraklastrowa badanej kolumny kiedy klastrowanie 
# jest przeprowadzone na pozostałych kolumnach.

# APN, ADM, FOM jest określone na przedziale 0,1 podczas gdy AD zmienia się od 0 do nieskończoności
# We wszystkich statystykach preferowane są niższe wartości 


summary(stab)
optimalScores(stab) # im mniejsze wartości, tym lepiej

#####################################################################################
# Uczenie nadzorowane - zbiór iris

hc.res <- eclust(scale(iris[,-5]), "hclust", k = 3, hc_metric = "euclidean", 
                 hc_method = "ward.D2", graph = FALSE)

table(iris$Species, hc.res$cluster)

134/nrow(iris)

# Compute cluster stats
clust_stats <- cluster.stats(dist(scale(iris[,-5])), 
                             as.numeric(iris$Species), 
                             hc.res$cluster)

# Indeksy mierzące poprawność klasyfikacji
clust_stats$corrected.rand # od -1 do 1
clust_stats$vi

# Obiekt zawiera dużo więcej statystyk..
clust_stats

# Opisy w pomocy
help("cluster.stats")

# Prognozowanie możemy wykonać za pomocą algorytmu K Najbliższych Sąsiadów lub LDA - będziemy to robić
# na najbliższych zajęciach.

#####################################################################################
# Klastrowanie hierarchiczne dzielące
dend.diana <- diana(d, stand = TRUE)

# wizualizacja
fviz_dend(dend.diana, cex = 0.5,
          k = 4, # Cut in four groups
          palette = "jco" # Color palette
)

# Interpretacja taka sama jak przy drzewach aglomeracyjnych

##############################################################################
# Klastrowanie niehierarchiczne

# Liczenie odległości
odleglosci <- get_dist(d, stand = TRUE, method = "pearson")
odleglosci <- get_dist(scale(d), stand = FALSE, method = "pearson")
fviz_dist(odleglosci, 
   gradient = list(low = "#00AFBB", mid = "white", high = "#FC4E07"))

# Wybór klastrów metodą gap_stat
fviz_nbclust(scale(d), kmeans, method = "gap_stat")

# Wybór klastrów wykresem łokcia - kryterium Within Sum of Squares
fviz_nbclust(scale(d), kmeans, method = "wss") 

# Wybór klastrów wykresem łokcia - kryterium Silhouette
fviz_nbclust(scale(d), kmeans, method = "silhouette") 

# Jeśli ktoś nie chce być specjalistą od segmentacji...
nb <- NbClust(scale(d), min.nc = 2,
              max.nc = 10, method = "kmeans")

# policzenie klastrów
km <- kmeans(scale(d), 3, nstart = 25)

print(km)

# Przypisanie wyników do bazy
f$klastry <- km$cluster

# Inne wielkości
km$size
km$centers

# Wizualizacja klastrów
fviz_cluster(km, data = scale(d),
             palette = c("#2E9FDF", "#00AFBB", "#E7B800", "#FC4E07"), 
             ellipse.type = "euclid", # Concentration ellipse
             repel = F, # Avoid label overplotting (slow)
             labelsize = 8,
             ggtheme = theme_minimal()
)

# Lub...
pam <- pam(scale(d), 3)

fviz_cluster(pam, data = d, frame.type = "convex")+
  theme_minimal()

odl <- dist(scale(d))
# Przeprowadź diagnostykę dla modelu pam i km
km.stats <- fpc::cluster.stats(odl,km$cluster) # przyjrzyjmy się statystykom Dunna oraz Calinksiego i Harabasza 
pam.stats <- fpc::cluster.stats(odl,pam$cluster)


mean(scale(scale(d), -mean(d), 1/sd(d)))

mean(d)

# im więcej tym lepiej
km.stats$dunn
pam.stats$dunn 

# im więcej tym lepiej
km.stats$ch
pam.stats$ch

# Można też zerknąć na pakiet ClusterSim:
# https://cran.r-project.org/web/packages/clusterSim/clusterSim.pdf

################################################################################
# Połączenie klastrowania k-średnich i hierarchicznego
# 
# Procedura:
# 1. Przeprowadzenie segmentacji metodą hierarchiczną
# 2. Policzenie środków klastrów i użycie ich jako punktów startowych w metodzie 
# k-średnich

# Mamy gotową procedurę:
obiekt.hk <-hkmeans(scale(d), 4)

fviz_dend(obiekt.hk, cex = 0.6, palette = "jco", 
          rect = TRUE, rect_border = "jco", rect_fill = TRUE)

fviz_cluster(obiekt.hk, palette = "jco", repel = T,
             ggtheme = theme_classic())


#################################################################################
# Hierarchical Clustering on Principal Components)

# Można wykorzystać:
# PCA (zmienne ciągłe)
# CA, MCA (zmienne dyskretne)

data("decathlon")
decathlon

obiekt.pca <- PCA(decathlon[,-c(11:13)], ncp = Inf)
obiekt.pca$eig

# Wybieramy 4 komponenty do dalszej analizy 
# (i określamy minimalną i maksymalną liczbę klastrów rozpatrywanych na zajęciach):

wyniki <- HCPC(obiekt.pca, min = 3, max = 10)
plot(wyniki, axes = 2:3)

######################################################################################
# Fuzzy-c clustering

# Liczenie klastrów
res.fanny <- fanny(d, 2) # liczba klastrów

# Podsumowanie
summary(res.fanny)

# Wyświetlenie parametrów
head(res.fanny$membership, 3)

# Wyświetlenie parametru Dunna
res.fanny$coeff

# Zmienna informująca o przynależności do klastra
head(res.fanny$clustering) 

# Wizualizacja
fviz_cluster(res.fanny, ellipse.type = "norm", repel = TRUE,
             palette = "jco", ggtheme = theme_minimal(),
             legend = "right")
fviz_silhouette(res.fanny, palette = "jco",
                ggtheme = theme_minimal())

######################################################################################
# Model-based clustering

# Wczytanie danych

# Standaryzacja danych
mc <- Mclust(d)
summary(mc)

# Nazwa modelu
mc$modelName                
# Optymalna liczba klastrów
mc$G                       
# Prawdopodobieństwo przynależności do klastra
head(mc$z, 30)             

# Przynależność do klastra każdej obserwacji na podstawie p-stwa
head(mc$classification, 30)

# Wizualizacja i diagnostyka

# BIC dla modeli i liczby klastrów
fviz_mclust(mc, "BIC", palette = "jco")

# Klasyfikacja na podstawie rozkładów
fviz_mclust(mc, "classification", geom = "point", 
            pointsize = 1.5, palette = "jco")

# Niepewność (wielkości kropek)
fviz_mclust(mc, "uncertainty", palette = "jco")

# DBSCAN: Density-Based Clustering Essentials

# Klasyczne klastrowanie k-średnich zawodzi:
data("multishapes")
df <- multishapes[, 1:2]
set.seed(123)
km.res <- kmeans(df, 5, nstart = 25)
fviz_cluster(km.res, df,  geom = "point", 
             ellipse= FALSE, show.clust.cent = FALSE,
             palette = "jco", ggtheme = theme_classic())

# Policzenie modelu
set.seed(123)
db <- fpc::dbscan(df, eps = 0.15, MinPts = 5)
# Wizualizacja
fviz_cluster(db, data = df, stand = FALSE,
             ellipse = FALSE, show.clust.cent = FALSE,
             geom = "point",palette = "jco", ggtheme = theme_classic())

print(db)
# Klastry
db$cluster

# Wybór epsilon
dbscan::kNNdistplot(df, k =  5)
abline(h = 0.15, lty = 2)