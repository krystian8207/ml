x <- c("a" = 1, "b" = 10, "c" = 12, "d" = 50)
d <- get_dist(x)
dend1 <- hclust(d)
fviz_dend(dend1)
c1 <- cophenetic(dend1) %>% as.vector()

dend2 <- hclust(d, method = "average")
fviz_dend(dend2)
c2 <- cophenetic(dend2) %>% as.vector()

cor_cophenetic(dend1, dend2)
cor(c1, c2)
