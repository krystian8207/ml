library(factoextra)
x <- 20 * (runif(100) - 0.5)
y <- runif(100)
df <- data.frame(x, y)
df2 <- spdep::Rotation(df, pi/3)
df2 <- as.data.frame(df2)
names(df2) <- c("x", "y")
df3 <- spdep::Rotation(df, 2 * pi/3)
df3 <- as.data.frame(df3)
names(df3) <- c("x", "y")

df <- rbind(df, df2, df3)

plot(df)

odleglosci2 <- get_dist(df, stand = TRUE)
fviz_dist(odleglosci2, 
          gradient = list(low = "#00AFBB", mid = "white", high = "#FC4E07"))

odleglosci3 <- stats::as.dist(1 - lsa::cosine(t(as.matrix(df)))^2)
fviz_dist(odleglosci3, 
          gradient = list(low = "#00AFBB", mid = "white", high = "#FC4E07"), order = FALSE)

mod <- hcut(odleglosci3, # dane
            k = 3, # liczba klastrów
            stand = FALSE, # czy standaryzujemy?
            hc_method = "ward.D2" # jaką metodą liczymy najbliższego sąsiada
)

fviz_dend(mod, 
          rect = TRUE,# czy zaznaczać klastry prostokątami?
          cex = 0.5, # wielkość czcionki
          type = "rectangle", #"circular", "phylogenic")) # kolory dla klastrów
)

klastry <- cutree(mod, k = 3)

fviz_cluster(list(data = df, cluster = klastry),
             ellipse.type = "convex", # Concentration ellipse
             repel = F, # Avoid label overplotting (slow)
             labelsize = 10, 
             show.clust.cent = FALSE, ggtheme = theme_minimal())

# kmeans

mod_km <- kmeans(df, 3)
fviz_cluster(mod_km, data = df,
             repel = F, # Avoid label overplotting (slow)
             labelsize = 8,
             ggtheme = theme_minimal()
)
